package com.evertschavez.reigndemo.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.evertschavez.reigndemo.R

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val articlesFragment = ArticlesFragment()
        supportFragmentManager.beginTransaction().add(
            R.id.placeholder, articlesFragment
        ).commit()
    }
}