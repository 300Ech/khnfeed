package com.evertschavez.reigndemo.adapters;

import android.view.View;

class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ArticleHolder>() {


}
